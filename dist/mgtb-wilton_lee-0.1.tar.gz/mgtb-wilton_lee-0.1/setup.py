from setuptools import setup, find_packages

with open("README.md", "r") as fh:
	long_description = fh.read()

setup(
    name='mgtb-wilton_lee',
    version='0.1',
    license='BSD 2.0',
    url="https://github.com/starttolearning/mergetables",
    description="A simple script to merger excel files with same template.",
    author='Wilton Lee',
    author_email='lz747938484@gmail.com',
	long_description=long_description,
	long_description_content_type="text/markdown",
	packages=find_packages(),
    install_requires=[
        'xlrd',
        'xlwt',
    ],
    python_requires=">=3.6",
    entry_points='''
        [console_scripts]
        mgtb=mgtb:mgtb
    ''',
)
